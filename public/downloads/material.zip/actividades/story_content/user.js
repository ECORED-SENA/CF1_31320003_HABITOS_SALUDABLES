function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5Vyocl31QIy":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

